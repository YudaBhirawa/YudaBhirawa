#include <iostream>
#include <vector>
#include <limits>

using namespace std;

typedef vector<vector<int>> Matriks;

// Fungsi untuk mencari elemen maksimum, minimum, dan posisinya
void cariMaxMin(const Matriks& matriks, int& maksimum, int& minBaris, int& minKolom,
                int& minimum, int& maxBaris, int& maxKolom) {
    maksimum = numeric_limits<int>::min();
    minimum = numeric_limits<int>::max();

    for (size_t i = 0; i < matriks.size(); ++i) {
        for (size_t j = 0; j < matriks[i].size(); ++j) {
            if (matriks[i][j] > maksimum) {
                maksimum = matriks[i][j];
                maxBaris = i;
                maxKolom = j;
            }
            if (matriks[i][j] < minimum) {
                minimum = matriks[i][j];
                minBaris = i;
                minKolom = j;
            }
        }
    }
}

int main() {
    int baris, kolom;

    // Meminta input ukuran matriks
    cout << "Masukkan jumlah baris: ";
    cin >> baris;
    cout << "Masukkan jumlah kolom: ";
    cin >> kolom;

    // Inisialisasi matriks
    Matriks matriks(baris, vector<int>(kolom));

    // Memasukkan elemen matriks
    cout << "Masukkan elemen-elemen matriks:\n";
    for (int i = 0; i < baris; ++i) {
        for (int j = 0; j < kolom; ++j) {
            cout << "Elemen [" << i + 1 << "][" << j + 1 << "]: ";
            cin >> matriks[i][j];
        }
    }

    // Variabel untuk menyimpan hasil
    int maksimum, maxBaris, maxKolom;
    int minimum, minBaris, minKolom;

    // Mencari nilai maksimum, minimum, dan posisinya
    cariMaxMin(matriks, maksimum, maxBaris, maxKolom, minimum, minBaris, minKolom);

    // Menampilkan hasil
    cout << "\nMatriks yang dimasukkan:\n";
    for (const auto& baris : matriks) {
        for (const auto& elemen : baris) {
            cout << elemen << " ";
        }
        cout << endl;
    }

    cout << "\nNilai maksimum: " << maksimum
         << " pada posisi [" << maxBaris + 1 << "][" << maxKolom + 1 << "]" << endl;
    cout << "Nilai minimum: " << minimum
         << " pada posisi [" << minBaris + 1 << "][" << minKolom + 1 << "]" << endl;

    return 0;
}
